import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk

# Configuration
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

class LoginScreen(ctk.CTkFrame):
    def __init__(self, parent, on_login_success):
        # Initialize as a transparent frame filling the parent
        super().__init__(parent, fg_color="transparent")
        self.on_login_success = on_login_success
        self.pack(fill="both", expand=True)
        
        self.create_widgets()

    def create_widgets(self):
        # --- THE LOGIN CARD (Frame) ---
        # We center this frame using relx/rely
        # Using the user's corner_radius and logic
        self.login_frame = ctk.CTkFrame(self, corner_radius=15) 
        self.login_frame.place(relx=0.5, rely=0.5, anchor="center")

        # Title inside the card
        self.label_title = ctk.CTkLabel(
            self.login_frame, 
            text="System Login", 
            font=("Roboto Medium", 24)
        )
        self.label_title.grid(row=0, column=0, padx=30, pady=(30, 10))

        # Subtitle
        self.label_subtitle = ctk.CTkLabel(
            self.login_frame, 
            text="Sign in to access the monitor", 
            font=("Roboto", 12), 
            text_color="gray"
        )
        self.label_subtitle.grid(row=1, column=0, padx=10, pady=(0, 20))

        # Username Entry
        self.entry_user = ctk.CTkEntry(
            self.login_frame, 
            width=220, 
            placeholder_text="Username"
        )
        self.entry_user.grid(row=2, column=0, padx=30, pady=(10, 10))

        # Password Entry
        self.entry_pass = ctk.CTkEntry(
            self.login_frame, 
            width=220, 
            show="*", 
            placeholder_text="Password"
        )
        self.entry_pass.grid(row=3, column=0, padx=30, pady=(0, 20))

        # Login Button
        self.btn_login = ctk.CTkButton(
            self.login_frame, 
            text="Login", 
            width=220, 
            command=self.login_event
        )
        self.btn_login.grid(row=4, column=0, padx=30, pady=(0, 10))


    def login_event(self):
        u = self.entry_user.get()
        p = self.entry_pass.get()
        
        print(f"Login attempt: {u}")
        
        # Authentication Logic
        if u == "admin" and p == "admin":
             # messagebox.showinfo("Success", "Login Successful!") # Skip info box for smoother UX
             self.on_login_success()
        else:
             messagebox.showerror("Error", "Invalid Credentials")
