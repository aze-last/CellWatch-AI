import tkinter as tk
from tkinter import ttk, messagebox
import customtkinter as ctk
import monitor_app.utils as utils

class IncidentsScreen(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.pack(fill="both", expand=True)

        # CustomTkinter tabs (matches your redesign)
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self.tabview = ctk.CTkTabview(self)
        self.tabview.grid(row=0, column=0, sticky="nsew", padx=20, pady=(10, 20))

        self.tab_handling = self.tabview.add("Incident Handling & Validation")
        self.tab_history = self.tabview.add("Incident History Log")

        self.review_tab = IncidentReviewDetail(self.tab_handling)
        self.review_tab.pack(fill="both", expand=True)

        self.log_tab = IncidentLogTable(self.tab_history)
        self.log_tab.pack(fill="both", expand=True)

class IncidentReviewDetail(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.create_widgets()
        
    def create_widgets(self):
        # Split tab into two columns: Left for Video, Right for Details
        self.grid_columnconfigure(0, weight=3)  # Video side is wider
        self.grid_columnconfigure(1, weight=2)  # Details side
        self.grid_rowconfigure(0, weight=1)

        # ================== LEFT PANEL (VIDEO) ==================
        self.left_panel = ctk.CTkFrame(self, fg_color="transparent")
        self.left_panel.grid(row=0, column=0, sticky="nsew", padx=(0, 15), pady=10)

        ctk.CTkLabel(
            self.left_panel, text="Evidence Playback", font=("Roboto", 18, "bold")
        ).pack(anchor="w", pady=(0, 10))

        # Video player placeholder
        self.video_player = ctk.CTkFrame(self.left_panel, fg_color="black", corner_radius=0)
        self.video_player.pack(fill="both", expand=True)
        ctk.CTkLabel(
            self.video_player, text="[VIDEO CLIP PLAYBACK]", text_color="gray"
        ).place(relx=0.5, rely=0.5, anchor="center")

        # Playback controls
        self.controls_frame = ctk.CTkFrame(self.left_panel, fg_color="transparent")
        self.controls_frame.pack(pady=15)

        btn_font = ("Roboto", 12, "bold")
        ctk.CTkButton(self.controls_frame, text="<< 10s", width=90, height=35, font=btn_font).pack(
            side="left", padx=5
        )
        ctk.CTkButton(self.controls_frame, text="Play / Pause", width=110, height=35, font=btn_font).pack(
            side="left", padx=5
        )
        ctk.CTkButton(self.controls_frame, text="10s >>", width=90, height=35, font=btn_font).pack(
            side="left", padx=5
        )

        # ================== RIGHT PANEL (DETAILS & VALIDATION) ==================
        self.right_panel = ctk.CTkFrame(self, fg_color="#2b2b2b")
        self.right_panel.grid(row=0, column=1, sticky="nsew", pady=10)

        # --- Section 1: Incident Details ---
        details_container = ctk.CTkFrame(self.right_panel, fg_color="transparent")
        details_container.pack(fill="x", padx=25, pady=25)

        ctk.CTkLabel(details_container, text="Incident Details", font=("Roboto", 18, "bold")).pack(
            anchor="w", pady=(0, 15)
        )

        def add_detail_row(parent, label, value):
            row = ctk.CTkFrame(parent, fg_color="transparent")
            row.pack(fill="x", pady=4)
            ctk.CTkLabel(
                row,
                text=label,
                font=("Roboto", 12, "bold"),
                width=110,
                anchor="w",
                text_color="#aaaaaa",
            ).pack(side="left")
            ctk.CTkLabel(row, text=value, font=("Roboto", 12), anchor="w").pack(side="left")

        add_detail_row(details_container, "Incident ID:", "INC-2023-001")
        add_detail_row(details_container, "Camera:", "Camera 03")
        add_detail_row(details_container, "Timestamp:", "14:30:22")

        row = ctk.CTkFrame(details_container, fg_color="transparent")
        row.pack(fill="x", pady=4)
        ctk.CTkLabel(
            row, text="Detected:", font=("Roboto", 12, "bold"), width=110, anchor="w", text_color="#aaaaaa"
        ).pack(side="left")
        ctk.CTkLabel(
            row, text="Aggressive Behavior", font=("Roboto", 12, "bold"), anchor="w", text_color="#d9534f"
        ).pack(side="left")

        # Separator Line
        ctk.CTkFrame(self.right_panel, height=2, fg_color="#404040").pack(fill="x", padx=25, pady=5)

        # --- Section 2: Operator Validation ---
        validation_container = ctk.CTkFrame(self.right_panel, fg_color="transparent")
        validation_container.pack(fill="both", expand=True, padx=25, pady=25)

        ctk.CTkLabel(validation_container, text="Operator Validation", font=("Roboto", 18, "bold")).pack(
            anchor="w", pady=(0, 10)
        )
        ctk.CTkLabel(validation_container, text="Comments:", font=("Roboto", 12, "bold"), text_color="#aaaaaa").pack(
            anchor="w"
        )

        self.comment_box = ctk.CTkTextbox(validation_container, height=120, font=("Roboto", 12))
        self.comment_box.pack(fill="x", pady=(5, 25))

        btn_style = {"height": 45, "font": ("Roboto", 13, "bold")}
        ctk.CTkButton(
            validation_container,
            text="CONFIRM INCIDENT",
            fg_color="#d9534f",
            hover_color="#c9302c",
            command=self.submit_confirm,
            **btn_style,
        ).pack(fill="x", pady=6)
        ctk.CTkButton(
            validation_container,
            text="FALSE ALARM / IGNORE",
            fg_color="#5cb85c",
            hover_color="#4cae4c",
            command=self.submit_ignore,
            **btn_style,
        ).pack(fill="x", pady=6)
        ctk.CTkButton(
            validation_container,
            text="MARK FOR REVIEW",
            fg_color="#0275d8",
            hover_color="#025aa5",
            command=self.submit_review,
            **btn_style,
        ).pack(fill="x", pady=6)
        
    def submit_confirm(self):
        messagebox.showinfo("Submitted", "Incident marked as VALID confirmed.")
        if hasattr(self, "comment_box") and self.comment_box is not None:
            self.comment_box.delete("1.0", tk.END)

    def submit_ignore(self):
        messagebox.showinfo("Submitted", "Incident marked as False Alarm.")
        
    def submit_review(self):
        messagebox.showinfo("Submitted", "Incident flagged for supervisor review.")

class IncidentLogTable(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.create_widgets()
        
    def create_widgets(self):
        # Toolbar
        toolbar = ttk.Frame(self)
        toolbar.pack(fill="x", pady=5)
        
        ttk.Label(toolbar, text="Search:").pack(side="left", padx=5)
        ttk.Entry(toolbar).pack(side="left", padx=5)
        ttk.Button(toolbar, text="Filter").pack(side="left")
        ttk.Button(toolbar, text="Export CSV").pack(side="right", padx=5)
        
        # Table
        columns = ("id", "time", "cam", "type", "status", "operator")
        self.tree = ttk.Treeview(self, columns=columns, show="headings", height=15)
        
        self.tree.heading("id", text="ID")
        self.tree.heading("time", text="Time")
        self.tree.heading("cam", text="Camera")
        self.tree.heading("type", text="Type")
        self.tree.heading("status", text="Validation")
        self.tree.heading("operator", text="Operator")
        
        self.tree.column("id", width=80)
        self.tree.column("time", width=120)
        self.tree.column("cam", width=80)
        
        self.tree.pack(fill="both", expand=True)
        
        # Dummy Data
        data = [
            ("INC-001", "2023-10-27 10:00", "Cam 1", "Aggressive", "Confirmed", "Admin"),
            ("INC-002", "2023-10-27 10:05", "Cam 2", "Falling", "False Alarm", "Admin"),
            ("INC-003", "2023-10-27 11:30", "Cam 1", "Contraband", "Pending", "-"),
        ]
        
        for item in data:
            self.tree.insert("", tk.END, values=item)
