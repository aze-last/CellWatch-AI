import cv2
import numpy as np
import time
from collections import deque

# Try importing TensorFlow (MoveNet dependency)
TF_AVAILABLE = False
TF_IMPORT_ERROR = None
HUB_AVAILABLE = False
HUB_IMPORT_ERROR = None

try:
    import tensorflow as tf
    TF_AVAILABLE = True
except Exception as e:
    TF_IMPORT_ERROR = e
    print(f"TensorFlow Import Warning: {e}")

if TF_AVAILABLE:
    try:
        import tensorflow_hub as hub
        HUB_AVAILABLE = True
    except Exception as e:
        HUB_IMPORT_ERROR = e
        print(f"TensorFlow Hub Import Warning: {e}")

class MotionOptimizedEngine:
    def __init__(self, debug=False, sensitivity="medium", enable_yolo=False, prefer_gpu=True, force_gpu=True, force_yolo_gpu=True):
        """
        Motion-optimized detection engine.
        Only runs heavy AI (MoveNet/YOLO) when motion is detected.
        
        Args:
            debug: Print motion scores and detection info
            sensitivity: "high", "medium", "low" for behavior detection
            enable_yolo: Enable YOLOv8 contraband detection
            prefer_gpu: Prefer GPU when available
            force_gpu: If True, try to force GPU-only execution
            force_yolo_gpu: If True, force YOLO to use GPU when available
        """
        print("Initializing Motion-Optimized AI Engine...")
        self.debug = debug
        self.enable_yolo = enable_yolo
        self.prefer_gpu = prefer_gpu
        self.force_gpu = force_gpu
        self.force_yolo_gpu = force_yolo_gpu
        self.tf_available = TF_AVAILABLE
        self.hub_available = HUB_AVAILABLE
        self.tf_error = TF_IMPORT_ERROR
        self.hub_error = HUB_IMPORT_ERROR
        self.gpu_enabled = False
        
        # Motion detection settings
        self.motion_threshold = 5000  # Pixel change threshold
        self.motion_history_size = 5  # Frames to average
        
        # Background subtractor per camera
        self.bg_subtractors = {}
        self.motion_history = {}
        self.last_gray_frames = {}
        
        # AI detection settings
        self.set_sensitivity(sensitivity)
        self.check_gpu()
        self.load_movenet()
        
        # Load YOLO if enabled
        if self.enable_yolo:
            self.load_yolo()
        
        # Pose estimation components
        self.EDGES = [
            (0, 1), (0, 2), (1, 3), (2, 4),
            (0, 5), (0, 6), (5, 7), (7, 9),
            (6, 8), (8, 10), (5, 6), (5, 11),
            (6, 12), (11, 12), (11, 13), (13, 15),
            (12, 14), (14, 16)
        ]
        
        self.trackers = {}
        
        # Performance stats
        self.stats = {
            'total_frames': 0,
            'motion_detected': 0,
            'ai_processed': 0,
            'skipped_frames': 0
        }
        
        print("Engine initialized successfully!")

    def set_sensitivity(self, level):
        """Set behavior detection sensitivity."""
        if level == "high":
            self.AGGRESSIVE_THRESHOLD = 0.3
            self.ACTIVE_THRESHOLD = 0.15
            self.ALERT_FRAMES = 2
        elif level == "low":
            self.AGGRESSIVE_THRESHOLD = 1.5
            self.ACTIVE_THRESHOLD = 0.8
            self.ALERT_FRAMES = 5
        else:  # medium
            self.AGGRESSIVE_THRESHOLD = 0.5
            self.ACTIVE_THRESHOLD = 0.25
            self.ALERT_FRAMES = 3
        
        if self.debug:
            print(f"Sensitivity: {level.upper()}")

    def check_gpu(self):
        """Check and enable GPU."""
        if not TF_AVAILABLE:
            msg = f"WARNING: TensorFlow not available, GPU check skipped. ({self.tf_error})"
            print(msg)
            return False
        if not self.prefer_gpu:
            print("GPU use disabled by configuration.")
            return False

        gpus = tf.config.list_physical_devices('GPU')
        if not gpus:
            print("WARNING: Running on CPU (no GPU detected)")
            return False

        try:
            if self.force_gpu:
                tf.config.set_visible_devices(gpus, 'GPU')
            for gpu in gpus:
                tf.config.experimental.set_memory_growth(gpu, True)
            self.gpu_enabled = True
            print(f"GPU ENABLED: {gpus[0].name}")
            return True
        except RuntimeError as e:
            print(f"GPU Error: {e}")
            return False

    def load_movenet(self):
        """Load MoveNet MultiPose model."""
        if not TF_AVAILABLE:
            print(f"MoveNet disabled (TensorFlow missing). ({self.tf_error})")
            self.movenet = None
            return
        if not HUB_AVAILABLE:
            print(f"MoveNet disabled (tensorflow_hub missing). ({self.hub_error})")
            self.movenet = None
            return

        print("Loading MoveNet MultiPose...")
        try:
            self.movenet_model = hub.load("https://tfhub.dev/google/movenet/multipose/lightning/1")
            self.movenet = self.movenet_model.signatures["serving_default"]
            print("MoveNet loaded!")
        except Exception as e:
            print(f"Failed to load MoveNet: {e}")
            self.movenet = None

    def load_yolo(self):
        """Load YOLOv8 for contraband detection."""
        try:
            from ultralytics import YOLO
            import torch
            
            # Auto-detect device (prefer/force GPU if available)
            if self.force_yolo_gpu and torch.cuda.is_available():
                self.yolo_device = 0
                torch.cuda.set_device(0)
            else:
                self.yolo_device = 0 if torch.cuda.is_available() else 'cpu'
            
            print(f"Loading YOLOv8... (Device: {self.yolo_device})")
            self.yolo_model = YOLO('yolov8n.pt')
            self.contraband_items = ['cell phone', 'knife', 'scissors', 'bottle']
            self.phone_conf_threshold = 0.15  # Lower threshold for phone detection
            self.contraband_conf_threshold = 0.5  # Higher for other items
            print(f"YOLOv8 loaded! Phone detection threshold: {self.phone_conf_threshold}")
        except ImportError:
            print("WARNING: ultralytics not installed. YOLO disabled.")
            print("Install with: pip install ultralytics")
            self.enable_yolo = False
            self.yolo_device = 'cpu'

    def detect_motion(self, frame, camera_id):
        """
        STAGE 1: Motion Detection (Lightweight)
        Returns True if significant motion detected.
        """
        # Initialize for new camera
        if camera_id not in self.bg_subtractors:
            self.bg_subtractors[camera_id] = cv2.createBackgroundSubtractorMOG2(
                history=500, 
                varThreshold=16, 
                detectShadows=False
            )
            self.motion_history[camera_id] = deque(maxlen=self.motion_history_size)
            self.last_gray_frames[camera_id] = None
        
        # Convert to grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (21, 21), 0)
        
        # METHOD 1: Background Subtraction
        fg_mask = self.bg_subtractors[camera_id].apply(gray)
        motion_pixels_bg = cv2.countNonZero(fg_mask)
        
        # METHOD 2: Frame Differencing (if we have previous frame)
        motion_pixels_diff = 0
        if self.last_gray_frames[camera_id] is not None:
            frame_diff = cv2.absdiff(self.last_gray_frames[camera_id], gray)
            _, thresh = cv2.threshold(frame_diff, 25, 255, cv2.THRESH_BINARY)
            motion_pixels_diff = cv2.countNonZero(thresh)
        
        # Update last frame
        self.last_gray_frames[camera_id] = gray
        
        # Combine both methods
        motion_score = max(motion_pixels_bg, motion_pixels_diff)
        
        # Add to history for smoothing
        self.motion_history[camera_id].append(motion_score)
        avg_motion = np.mean(self.motion_history[camera_id])
        
        # Determine if motion is significant
        motion_detected = avg_motion > self.motion_threshold
        
        if self.debug and motion_detected:
            print(f"[{camera_id}] Motion: {avg_motion:.0f} pixels (threshold: {self.motion_threshold})")
        
        return motion_detected, avg_motion

    def process_frame(self, frame, camera_id="cam_0"):
        """
        Main processing pipeline with motion optimization.
        
        Returns dict with:
        - frame: processed frame
        - motion_detected: bool
        - motion_score: float
        - num_people: int
        - alert_triggered: bool
        - alerts: list
        - detections: dict
        - processing_mode: "motion_only" or "full_ai"
        """
        self.stats['total_frames'] += 1
        
        # STAGE 1: Quick motion check
        motion_detected, motion_score = self.detect_motion(frame, camera_id)
        
        results = {
            "frame": frame.copy(),
            "motion_detected": motion_detected,
            "motion_score": motion_score,
            "num_people": 0,
            "alert_triggered": False,
            "active_movement": False,
            "alerts": [],
            "detections": {"behavior": [], "contraband": []},
            "processing_mode": "motion_only"
        }
        
        # If NO motion detected, skip heavy AI processing
        if not motion_detected:
            self.stats['skipped_frames'] += 1
            
            # Draw "NO MOTION" indicator
            cv2.putText(results["frame"], "No Motion - AI Idle", 
                       (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                       0.7, (128, 128, 128), 2)
            
            return results
        
        # STAGE 2: Motion detected - Run full AI processing
        self.stats['motion_detected'] += 1
        self.stats['ai_processed'] += 1
        results["processing_mode"] = "full_ai"
        
        if self.movenet:
            # --- MoveNet Pose Detection ---
            input_image = cv2.resize(frame, (256, 256))
            input_image = tf.cast(input_image, dtype=tf.int32)
            input_image = tf.expand_dims(input_image, axis=0)

            if self.gpu_enabled:
                with tf.device('/GPU:0'):
                    output = self.movenet(input_image)
            else:
                output = self.movenet(input_image)
            keypoints_with_scores = output["output_0"].numpy()
            
            # Process each detected person
            for person_id in range(6):
                kps = keypoints_with_scores[0, person_id, :51].reshape(17, 3)
                avg_confidence = np.mean(kps[:, 2])
                
                if avg_confidence > 0.25:
                    results["num_people"] += 1
                    
                    # Draw pose
                    self.draw_pose(results["frame"], kps, person_id)
                    
                    # Classify behavior
                    label, score = self.classify_behavior(kps, person_id, camera_id)
                    self.draw_label(results["frame"], kps, person_id, label, score)
                    
                    detection = {
                        "person_id": person_id,
                        "label": label,
                        "score": score,
                        "confidence": avg_confidence
                    }
                    results["detections"]["behavior"].append(detection)
                    
                    if "Aggressive" in label:
                        results["alert_triggered"] = True
                        results["alerts"].append(f"Person {person_id + 1}: {label}")
                    elif "Fast" in label or "Active" in label:
                        results["active_movement"] = True
        elif self.debug:
            # If MoveNet is disabled/missing, we can't do pose detection
            results["processing_mode"] = "motion_only (TF missing)"
        
        # --- YOLOv8 Detection (if enabled) ---
        if self.enable_yolo:
            # If MoveNet is disabled, use YOLO to detect people too
            if not self.movenet:
                people_detected = self.detect_people_yolo(results["frame"])
                results["num_people"] = len(people_detected)
                
                # Draw people boxes
                for person in people_detected:
                    x1, y1, x2, y2 = person['bbox']
                    cv2.rectangle(results["frame"], (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.putText(results["frame"], f"Person {person['confidence']:.2f}",
                               (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            
            # Detect contraband
            contraband = self.detect_contraband(results["frame"])
            results["detections"]["contraband"] = contraband
            
            if contraband:
                results["alert_triggered"] = True
                for item in contraband:
                    results["alerts"].append(f"Contraband: {item['item']}")
        
        # Draw motion indicator
        cv2.putText(results["frame"], "AI ACTIVE - Motion Detected", 
                   (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                   0.7, (0, 255, 0), 2)
        
        return results

    def detect_contraband(self, frame):
        """YOLO contraband detection."""
        if not self.enable_yolo:
            return []
        
        detections = []
        # Run YOLO with auto-detected device
        results = self.yolo_model(frame, verbose=False, device=self.yolo_device)
        
        for result in results:
            for box in result.boxes:
                class_id = int(box.cls)
                class_name = self.yolo_model.names[class_id]
                confidence = float(box.conf)
                
                # Use lower threshold for phones
                threshold = self.phone_conf_threshold if class_name == 'cell phone' else self.contraband_conf_threshold
                
                if class_name in self.contraband_items and confidence > threshold:
                    x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                    
                    if self.debug:
                        print(f"CONTRABAND DETECTED: {class_name} ({confidence:.2f})")
                    
                    detections.append({
                        'item': class_name,
                        'confidence': confidence,
                        'bbox': (int(x1), int(y1), int(x2), int(y2))
                    })
                    
                    # Draw box
                    cv2.rectangle(frame, 
                                 (int(x1), int(y1)), 
                                 (int(x2), int(y2)), 
                                 (0, 0, 255), 3)
                    
                    label = f"{class_name} {confidence:.2f}"
                    cv2.putText(frame, label, 
                               (int(x1), int(y1) - 10),
                               cv2.FONT_HERSHEY_SIMPLEX, 
                               0.7, (0, 0, 255), 2)
        
        return detections
    
    def detect_people_yolo(self, frame):
        """Detect people using YOLO (fallback when MoveNet unavailable)."""
        if not self.enable_yolo:
            return []
        
        people = []
        # Run YOLO with auto-detected device
        results = self.yolo_model(frame, verbose=False, device=self.yolo_device)
        
        for result in results:
            for box in result.boxes:
                class_id = int(box.cls)
                class_name = self.yolo_model.names[class_id]
                confidence = float(box.conf)
                
                if class_name == 'person' and confidence > 0.5:
                    x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                    people.append({
                        'confidence': confidence,
                        'bbox': (int(x1), int(y1), int(x2), int(y2))
                    })
        
        return people

    def draw_pose(self, frame, keypoints, person_id, threshold=0.3):
        """Draw skeletal overlay."""
        h, w, _ = frame.shape
        colors = [(0, 255, 0), (255, 0, 0), (0, 255, 255),
                  (255, 255, 0), (255, 0, 255), (128, 255, 0)]
        color = colors[person_id % len(colors)]
        
        for y, x, c in keypoints:
            if c > threshold:
                cv2.circle(frame, (int(x * w), int(y * h)), 6, color, -1)
                cv2.circle(frame, (int(x * w), int(y * h)), 8, (255, 255, 255), 1)
        
        for p1, p2 in self.EDGES:
            y1, x1, c1 = keypoints[p1]
            y2, x2, c2 = keypoints[p2]
            if c1 > threshold and c2 > threshold:
                cv2.line(frame,
                         (int(x1 * w), int(y1 * h)),
                         (int(x2 * w), int(y2 * h)),
                         color, 3)

    def classify_behavior(self, keypoints, person_id, camera_id):
        """Rule-based behavior classification."""
        if camera_id not in self.trackers:
            self.trackers[camera_id] = {}
        
        tracker_map = self.trackers[camera_id]
        
        k = keypoints
        left_wrist = k[9][:2]
        right_wrist = k[10][:2]
        left_elbow = k[7][:2]
        right_elbow = k[8][:2]
        
        now = time.time()
        
        if person_id not in tracker_map:
            tracker_map[person_id] = {
                'prev_right_wrist': right_wrist,
                'prev_left_wrist': left_wrist,
                'prev_right_elbow': right_elbow,
                'prev_left_elbow': left_elbow,
                'prev_time': now,
                'motion_history': [],
                'alert_count': 0
            }
            return "Normal", 0.0
        
        tracker = tracker_map[person_id]
        dt = now - tracker['prev_time']
        
        if dt == 0 or dt > 0.5:
            tracker['prev_time'] = now
            return "Normal", 0.0
        
        # Calculate speeds
        right_wrist_speed = np.linalg.norm(right_wrist - tracker['prev_right_wrist']) / dt
        left_wrist_speed = np.linalg.norm(left_wrist - tracker['prev_left_wrist']) / dt
        right_elbow_speed = np.linalg.norm(right_elbow - tracker['prev_right_elbow']) / dt
        left_elbow_speed = np.linalg.norm(left_elbow - tracker['prev_left_elbow']) / dt
        
        wrist_motion = (right_wrist_speed + left_wrist_speed) / 2
        elbow_motion = (right_elbow_speed + left_elbow_speed) / 2
        motion_score = (wrist_motion * 0.7) + (elbow_motion * 0.3)
        
        # Update tracker
        tracker['prev_right_wrist'] = right_wrist
        tracker['prev_left_wrist'] = left_wrist
        tracker['prev_right_elbow'] = right_elbow
        tracker['prev_left_elbow'] = left_elbow
        tracker['prev_time'] = now
        
        tracker['motion_history'].append(motion_score)
        if len(tracker['motion_history']) > 5:
            tracker['motion_history'].pop(0)
        
        avg_motion = np.mean(tracker['motion_history'])
        
        if self.debug:
            print(f"[{camera_id}] P{person_id}: Behavior Motion={avg_motion:.3f}")
        
        # Classification
        if avg_motion > self.AGGRESSIVE_THRESHOLD:
            tracker['alert_count'] += 1
            if tracker['alert_count'] >= self.ALERT_FRAMES:
                return "Suspicious / Aggressive", avg_motion
            else:
                return "Fast Movement", avg_motion
        else:
            tracker['alert_count'] = max(0, tracker['alert_count'] - 1)
            
            if avg_motion > self.ACTIVE_THRESHOLD:
                return "Active Movement", avg_motion
            else:
                return "Normal", avg_motion

    def draw_label(self, frame, kps, person_id, label, score):
        """Draw behavior label near person."""
        h, w, _ = frame.shape
        nose = kps[0]
        
        label_x = max(10, min(int(nose[1] * w), w - 300))
        label_y = max(40, int(nose[0] * h) - 30)
        
        if "Aggressive" in label:
            color = (0, 0, 255)
        elif "Fast" in label or "Active" in label:
            color = (0, 165, 255)
        else:
            color = (0, 255, 0)
        
        text = f"P{person_id + 1}: {label}"
        text_size = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.65, 2)[0]
        
        overlay = frame.copy()
        cv2.rectangle(overlay,
                      (label_x - 6, label_y - text_size[1] - 6),
                      (label_x + text_size[0] + 6, label_y + 6),
                      (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.6, frame, 0.4, 0, frame)
        
        cv2.putText(frame, text, (label_x, label_y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.65, color, 2)
        cv2.putText(frame, f"Motion: {score:.2f}",
                    (label_x, label_y + 22),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

    def get_stats(self):
        """Get performance statistics."""
        total = self.stats['total_frames']
        if total == 0:
            return "No frames processed yet"
        
        efficiency = (self.stats['skipped_frames'] / total) * 100
        
        return {
            'total_frames': total,
            'motion_detected': self.stats['motion_detected'],
            'ai_processed': self.stats['ai_processed'],
            'skipped_frames': self.stats['skipped_frames'],
            'efficiency': f"{efficiency:.1f}%"
        }

    def reset_tracker(self, camera_id=None):
        """Reset tracking data."""
        if camera_id is None:
            self.trackers = {}
            self.bg_subtractors = {}
            self.motion_history = {}
            self.last_gray_frames = {}
            print("All trackers reset")
        else:
            if camera_id in self.trackers:
                self.trackers[camera_id] = {}
            if camera_id in self.bg_subtractors:
                del self.bg_subtractors[camera_id]
            if camera_id in self.motion_history:
                del self.motion_history[camera_id]
            if camera_id in self.last_gray_frames:
                del self.last_gray_frames[camera_id]
            print(f"Tracker reset for camera: {camera_id}")


# TEST SCRIPT
if __name__ == "__main__":
    print("="*60)
    print("MOTION-OPTIMIZED AI ENGINE TEST")
    print("="*60)
    
    # Initialize with high sensitivity for testing
    engine = MotionOptimizedEngine(
        debug=True, 
        sensitivity="high",
        enable_yolo=True  # YOLO enabled for phone + people detection
    )
    
    # Test with webcam (Try external first, then laptop)
    print("Attempting to open external webcam (index 1)...")
    cap = cv2.VideoCapture(1)
    
    if not cap.isOpened():
        print("External webcam not found. Falling back to laptop webcam (index 0)...")
        cap = cv2.VideoCapture(0)
    
    if not cap.isOpened():
        print("ERROR: Cannot open any webcam")
        exit()
    
    print("\nCONTROLS:")
    print("  q = Quit")
    print("  s = Show statistics")
    print("\nSTART TESTING:")
    print("- Sit still = No motion, AI skipped")
    print("- Move slowly = Motion detected, AI runs")
    print("- Wave arms fast = Aggressive behavior alert")
    print("="*60 + "\n")
    
    frame_count = 0
    start_time = time.time()
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        frame_count += 1
        
        # Process frame
        result = engine.process_frame(frame, camera_id="webcam_test")
        
        # Calculate FPS
        elapsed = time.time() - start_time
        fps = frame_count / elapsed if elapsed > 0 else 0
        
        # Draw FPS and stats
        cv2.putText(result["frame"], f"FPS: {fps:.1f}", 
                   (10, result["frame"].shape[0] - 60),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
        
        cv2.putText(result["frame"], f"Mode: {result['processing_mode']}", 
                   (10, result["frame"].shape[0] - 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        cv2.putText(result["frame"], f"People: {result['num_people']}", 
                   (10, result["frame"].shape[0] - 10),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        # Show alerts
        if result["alert_triggered"]:
            print("\n" + "!"*60)
            print("ALERT TRIGGERED:")
            for alert in result["alerts"]:
                print(f"  - {alert}")
            print("!"*60 + "\n")
        
        cv2.imshow("Motion-Optimized Engine Test", result["frame"])
        
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('s'):
            stats = engine.get_stats()
            print("\n" + "="*60)
            print("PERFORMANCE STATISTICS:")
            print(f"  Total Frames: {stats['total_frames']}")
            print(f"  Motion Detected: {stats['motion_detected']}")
            print(f"  AI Processed: {stats['ai_processed']}")
            print(f"  Skipped Frames: {stats['skipped_frames']}")
            print(f"  Efficiency: {stats['efficiency']} frames skipped")
            print("="*60 + "\n")
    
    # Final stats
    cap.release()
    cv2.destroyAllWindows()
    
    final_stats = engine.get_stats()
    print("\n" + "="*60)
    print("FINAL STATISTICS:")
    print(f"  Total Frames: {final_stats['total_frames']}")
    print(f"  AI Processed: {final_stats['ai_processed']}")
    print(f"  Skipped: {final_stats['skipped_frames']} ({final_stats['efficiency']})")
    print("="*60)
    print("\nTest completed!")
