import cv2
import numpy as np
import os
import time

# Try importing TensorFlow (MoveNet dependency)
TF_AVAILABLE = False
TF_IMPORT_ERROR = None
HUB_AVAILABLE = False
HUB_IMPORT_ERROR = None

try:
    import tensorflow as tf
    # Check if it's a real TF (has version attribute)
    if hasattr(tf, "__version__"):
        TF_AVAILABLE = True
    else:
        TF_AVAILABLE = False
        TF_IMPORT_ERROR = "Module 'tensorflow' is present but invalid (missing __version__)."
except Exception as e:
    TF_IMPORT_ERROR = e
    print(f"TensorFlow Import Warning: {e}")

if TF_AVAILABLE:
    try:
        import tensorflow_hub as hub
        HUB_AVAILABLE = True
    except Exception as e:
        HUB_IMPORT_ERROR = e
        print(f"TensorFlow Hub Import Warning: {e}")

try:
    from ultralytics import YOLO
    YOLO_AVAILABLE = True
except Exception as e:
    print(f"YOLOv8 Import Warning: {e}")
    YOLO_AVAILABLE = False

# Torch is optional – only needed for advanced YOLO usage.
# Do NOT hard‑fail if it's missing so the rest of the AI stack still works.
try:
    import torch
    print("CUDA available:", torch.cuda.is_available())
    print("CUDA device:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU")
except Exception as e:
    torch = None
    print(f"Torch Import Warning: {e} (YOLO will run on CPU only, if available)")

import time
from collections import deque
import threading

class BasicMotionEngine:
    def __init__(self, debug=False, sensitivity="medium"):
        print("Initializing BasicMotionEngine (Fallback)...")
        self.debug = debug
        self.sensitivity = sensitivity
        self.trackers = {}
        
        # Sensitivity thresholds (pixel intensity diff avg)
        if sensitivity == "high":
            self.MOTION_THRESHOLD = 1.5  # Lower = more sensitive
            self.ALERT_MULTIPLIER = 2.0  # Alert at 3.0
        elif sensitivity == "low":
            self.MOTION_THRESHOLD = 8.0
            self.ALERT_MULTIPLIER = 2.5
        else:
            self.MOTION_THRESHOLD = 3.0
            self.ALERT_MULTIPLIER = 2.0

    def process_frame(self, frame, camera_id="cam_0"):
        # Initialize tracker
        if camera_id not in self.trackers:
            self.trackers[camera_id] = {
                "prev_gray": None,
                "motion_score": 0
            }
        
        tracker = self.trackers[camera_id]
        
        # Convert to grayscale for motion analysis
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (21, 21), 0)
        
        motion_score = 0
        status = "Normal"
        alert_triggered = False
        alerts = []
        
        if tracker["prev_gray"] is not None:
            # Compute difference
            frame_delta = cv2.absdiff(tracker["prev_gray"], gray)
            motion_score = np.mean(frame_delta)
            
            if motion_score > self.MOTION_THRESHOLD:
                status = "Active Movement"
                if motion_score > self.MOTION_THRESHOLD * self.ALERT_MULTIPLIER:
                    status = "High Activity"
                    alert_triggered = True
                    alerts.append(f"High Activity Detected (Score: {motion_score:.1f})")
        
        tracker["prev_gray"] = gray
        
        # Draw Results
        results = {
            "frame": frame.copy(),
            "num_people": 0, # Cannot detect people count without AI
            "alert_triggered": alert_triggered,
            "active_movement": (status != "Normal"),
            "alerts": alerts,
            "detections": [] 
        }
        
        # Overlay status
        color = (0, 255, 0)
        if status != "Normal":
            color = (0, 165, 255) if not alert_triggered else (0, 0, 255)
            
        cv2.putText(results["frame"], f"Motion Mode: {status}", (10, 30), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        
        if self.debug:
            cv2.putText(results["frame"], f"Score: {motion_score:.2f}", (10, 60), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200, 200, 200), 1)
            
        return results


class YOLOv8Engine:
    """
    YOLOv8 contraband detection engine.

    Modes:
      A) Pretrained COCO model (e.g., yolov8n.pt)
         - Detects "cell phone" reliably
         - Weapons are NOT reliably supported (no knife class in COCO)
         - Optional demo mapping: treat "scissors" as weapon

      B) Custom fine-tuned model (best.pt) trained on:
         - cellphone
         - weapon
    """

    def __init__(self, model_path="yolov8n.pt", debug=False, sensitivity="medium", device=None):
        print(f"Initializing YOLOv8Engine... ({model_path})")
        self.debug = debug
        try:
            self.model = YOLO(model_path)
            self.coco_names = self.model.names if hasattr(self.model, "names") else {}
        except Exception as e:
             print(f"YOLOv8 Model Load Error: {e}")
             self.model = None

        # device: None = auto; or "cpu", "0" for GPU
        self.device = device if device is not None else "cpu"
        if self.model:
            print(f"YOLO Device: {self.device}")
        self.set_sensitivity(sensitivity)

        # For pretrained COCO model mapping:
        self.pretrained_label_map = {
            "cell phone": "cellphone",
            "scissors": "weapon"  # DEMO fallback
        }

    def set_sensitivity(self, level):
        if level == "high":
            self.CONF_THR = 0.25
            self.IOU_THR = 0.45
            print("YOLO Sensitivity: HIGH")
        elif level == "low":
            self.CONF_THR = 0.55
            self.IOU_THR = 0.50
            print("YOLO Sensitivity: LOW")
        else:
            self.CONF_THR = 0.40
            self.IOU_THR = 0.50
            print("YOLO Sensitivity: MEDIUM")

    def process_frame(self, frame, camera_id="cam_0"):
        """
        Returns a dict consistent with your MoveNetEngine output.
        """
        results = {
            "frame": frame.copy(),
            "num_people": None,  # not used here
            "alert_triggered": False,
            "active_movement": False,
            "alerts": [],
            "detections": []
        }
        
        if not self.model:
            return results

        # Run inference
        try:
            preds = self.model.predict(
                source=frame,
                conf=self.CONF_THR,
                iou=self.IOU_THR,
                verbose=False,
                device=self.device
            )

            if not preds:
                return results

            pred0 = preds[0]
            if pred0.boxes is None or len(pred0.boxes) == 0:
                return results

            h, w, _ = frame.shape

            for box in pred0.boxes:
                cls_id = int(box.cls[0].item())
                conf = float(box.conf[0].item())
                x1, y1, x2, y2 = box.xyxy[0].tolist()

                # label name from model
                # Safe access to dict for raw label
                if isinstance(self.coco_names, dict):
                    raw_name = self.coco_names.get(cls_id, str(cls_id))
                else: 
                    # If it's a list (older versions)
                    raw_name = self.coco_names[cls_id] if cls_id < len(self.coco_names) else str(cls_id)
                
                if self.debug:
                    print(f"DEBUG: YOLO saw '{raw_name}' ({conf:.2f})")
                    debug = True 
                # Decide final label:
                label = raw_name
                if raw_name in self.pretrained_label_map:
                    label = self.pretrained_label_map[raw_name]

                # We only care about our contraband classes
                if label not in ("cellphone", "weapon"):
                    continue

                # Draw box
                color = (0, 165, 255)  # orange
                if label == "weapon":
                    color = (0, 0, 255)  # red

                cv2.rectangle(results["frame"], (int(x1), int(y1)), (int(x2), int(y2)), color, 2)
                cv2.putText(
                    results["frame"], "YOLOv8: CONTRABAND ALERT",
                    (int(x1), max(25, int(y1) - 8)),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6,
                    color,
                    2
                )

                det = {
                    "label": label,
                    "confidence": conf,
                    "bbox": [float(x1), float(y1), float(x2), float(y2)]
                }
                results["detections"].append(det)

                # Alerts
                results["alert_triggered"] = True
                results["alerts"].append(f"{label.upper()} detected ({conf:.2f})")

            # Small header text
            if results["alert_triggered"]:
                cv2.putText(results["frame"], "YOLOv8: CONTRABAND ALERT", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255), 2)
            else:
                cv2.putText(results["frame"], "YOLOv8: Normal", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 255, 0), 2)

        except Exception as e:
            print(f"YOLO Inference Error: {e}")
            
        return results


class YOLOPhoneOnlyEngine:
    def __init__(self, model_path="yolov8n.pt", debug=False, conf=0.20, iou=0.45, device=None):
        """
        Phone-only detector using pretrained YOLOv8 COCO.
        Detects only COCO class: 'cell phone'
        """
        if not YOLO_AVAILABLE:
            raise RuntimeError("Ultralytics YOLO not available. Install/repair ultralytics first.")

        print(f"Initializing YOLOPhoneOnlyEngine... ({model_path})")
        self.debug = debug
        self.model = YOLO(model_path)
        self.names = self.model.names  # dict or list
        self.conf = conf
        self.iou = iou

        # Choose device: prefer GPU if torch + CUDA are available
        if device is not None:
            self.device = device
        else:
            if torch is not None and torch.cuda.is_available():
                # Ultralytics accepts "0" as first GPU
                self.device = "0"
                print("YOLOPhoneOnly: using GPU (device 0)")
            else:
                self.device = "cpu"
                print("YOLOPhoneOnly: GPU not available, using CPU")

        print(f"YOLOPhoneOnly Device: {self.device}, Conf: {self.conf}")

    def _get_name(self, cls_id: int) -> str:
        if isinstance(self.names, dict):
            return self.names.get(cls_id, str(cls_id))
        return self.names[cls_id] if cls_id < len(self.names) else str(cls_id)

    def process_frame(self, frame, camera_id="cam_0"):
        results = {
            "frame": frame,
            "alert_triggered": False,
            "alerts": [],
            "detections": [],
            "num_people": None,
            "active_movement": False
        }

        preds = self.model.predict(
            source=frame,
            # Slightly smaller image for better CPU performance while
            # keeping good phone accuracy.
            imgsz=416,
            conf=self.conf,         # lower = more sensitive
            iou=self.iou,
            verbose=False,
            device=self.device
        )

        if not preds or preds[0].boxes is None or len(preds[0].boxes) == 0:
            return results

        for box in preds[0].boxes:
            cls_id = int(box.cls[0].item())
            conf = float(box.conf[0].item())
            name = self._get_name(cls_id)

            if self.debug:
                print(f"YOLO saw: {name} ({conf:.2f})")

            # Only keep cell phone
            if name != "cell phone":
                continue

            x1, y1, x2, y2 = box.xyxy[0].tolist()

            # Draw
            cv2.rectangle(results["frame"], (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 255), 2)
            cv2.putText(
                results["frame"],
                f"PHONE {conf:.2f}",
                (int(x1), max(25, int(y1) - 8)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (0, 255, 255),
                2
            )

            results["detections"].append({
                "label": "cellphone",
                "confidence": conf,
                "bbox": [float(x1), float(y1), float(x2), float(y2)]
            })

            results["alert_triggered"] = True
            results["alerts"].append(f"CELLPHONE detected ({conf:.2f})")

        # Add status overlay
        if results["alert_triggered"]:
            cv2.putText(results["frame"], "YOLO: PHONE DETECTED!", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
        else:
            cv2.putText(results["frame"], "YOLO: Monitoring...", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

        return results


class MotionOptimizedEngine:
    def __init__(self, debug=False, sensitivity="medium", enable_yolo=False, prefer_gpu=True, force_gpu=True, force_yolo_gpu=True):
        """
        Motion-optimized detection engine.
        Only runs heavy AI (MoveNet/YOLO) when motion is detected.

        Args:
            debug: Print motion scores and detection info
            sensitivity: "high", "medium", "low" for behavior detection
            enable_yolo: Enable YOLOv8 contraband detection
            prefer_gpu: Prefer GPU when available
            force_gpu: If True, try to force GPU-only execution
            force_yolo_gpu: If True, force YOLO to use GPU when available
        """
        print("Initializing Motion-Optimized AI Engine...")
        self.debug = debug
        self.enable_yolo = enable_yolo
        self.prefer_gpu = prefer_gpu
        self.force_gpu = force_gpu
        self.force_yolo_gpu = force_yolo_gpu
        self.tf_available = TF_AVAILABLE
        self.hub_available = HUB_AVAILABLE
        self.tf_error = TF_IMPORT_ERROR
        self.hub_error = HUB_IMPORT_ERROR
        self.gpu_enabled = False

        # Motion detection settings
        self.motion_threshold = 5000  # Pixel change threshold
        self.motion_history_size = 5  # Frames to average

        # Background subtractor per camera
        self.bg_subtractors = {}
        self.motion_history = {}
        self.last_gray_frames = {}

        # AI detection settings
        self.set_sensitivity(sensitivity)
        self.check_gpu()
        self.load_movenet()

        # Load YOLO if enabled
        if self.enable_yolo:
            self.load_yolo()

        # Pose estimation components
        self.EDGES = [
            (0, 1), (0, 2), (1, 3), (2, 4),
            (0, 5), (0, 6), (5, 7), (7, 9),
            (6, 8), (8, 10), (5, 6), (5, 11),
            (6, 12), (11, 12), (11, 13), (13, 15),
            (12, 14), (14, 16)
        ]

        self.trackers = {}
        self.last_process_time = {}  # For throttling AI
        self.lock = threading.Lock() # Protect shared state

        # Performance stats
        self.stats = {
            'total_frames': 0,
            'motion_detected': 0,
            'ai_processed': 0,
            'skipped_frames': 0
        }
        
        # YOLO optimizations
        self.yolo_imgsz = 320  # Reduced for speed
        self.yolo_pose_model = None # Lazy load

        print("Engine initialized successfully!")

    def set_sensitivity(self, level):
        """Set behavior detection sensitivity."""
        if level == "high":
            self.AGGRESSIVE_THRESHOLD = 0.3
            self.ACTIVE_THRESHOLD = 0.15
            self.ALERT_FRAMES = 2
        elif level == "low":
            self.AGGRESSIVE_THRESHOLD = 1.5
            self.ACTIVE_THRESHOLD = 0.8
            self.ALERT_FRAMES = 5
        else:  # medium
            self.AGGRESSIVE_THRESHOLD = 0.5
            self.ACTIVE_THRESHOLD = 0.25
            self.ALERT_FRAMES = 3

        if self.debug:
            print(f"Sensitivity: {level.upper()}")

    def check_gpu(self):
        """Check and enable GPU."""
        if not TF_AVAILABLE:
            msg = f"WARNING: TensorFlow not available, GPU check skipped. ({self.tf_error})"
            print(msg)
            return False
        if not self.prefer_gpu:
            print("GPU use disabled by configuration.")
            return False

        try:
            gpus = tf.config.list_physical_devices('GPU')
            if not gpus:
                print("WARNING: Running on CPU (no GPU detected)")
                return False

            if self.force_gpu:
                tf.config.set_visible_devices(gpus, 'GPU')
            for gpu in gpus:
                tf.config.experimental.set_memory_growth(gpu, True)
            self.gpu_enabled = True
            print(f"GPU ENABLED: {gpus[0].name}")
            return True
        except Exception as e:
            print(f"GPU/TensorFlow Config Error: {e} (Falling back to CPU/YOLO-only)")
            return False

    def load_movenet(self):
        """Load MoveNet MultiPose model."""
        if not TF_AVAILABLE:
            print(f"MoveNet disabled (TensorFlow missing). ({self.tf_error})")
            self.movenet = None
            return

        print("Loading MoveNet MultiPose...")
        try:
            # Try offline path first
            base_dir = os.path.dirname(os.path.abspath(__file__))
            local_path = os.path.join(base_dir, "models", "movenet_multipose", "312f001449331ee3d410d758fccdc9945a65dbc3")
            
            if os.path.exists(os.path.join(local_path, "saved_model.pb")):
                print(f"MoveNet: Loading from local offline path (Bypassing Hub)...")
                # Using native tf.saved_model.load instead of hub.load for maximum robustness
                self.movenet_model = tf.saved_model.load(local_path)
                self.movenet = self.movenet_model.signatures["serving_default"]
            else:
                # Only use hub.load if available and online
                if not HUB_AVAILABLE or not hasattr(hub, 'load'):
                    print("MoveNet Error: Cannot load online model (tensorflow_hub missing or broken).")
                    self.movenet = None
                    return
                
                print("MoveNet: Loading from TF Hub (Online)...")
                self.movenet_model = hub.load("https://tfhub.dev/google/movenet/multipose/lightning/1")
                self.movenet = self.movenet_model.signatures["serving_default"]
                
            print("MoveNet loaded!")
        except Exception as e:
            print(f"Failed to load MoveNet: {e} (This is normal on Python 3.13)")
            self.movenet = None

    def load_yolo(self):
        """Load YOLOv8 for contraband detection."""
        try:
            from ultralytics import YOLO
            import torch

            # Auto-detect device (prefer/force GPU if available)
            if self.force_yolo_gpu and torch.cuda.is_available():
                self.yolo_device = 0
                torch.cuda.set_device(0)
            else:
                self.yolo_device = 0 if torch.cuda.is_available() else 'cpu'

            print(f"Loading YOLOv8... (Device: {self.yolo_device})")
            self.yolo_model = YOLO('yolov8n.pt')
            self.contraband_items = ['cell phone', 'knife', 'scissors', 'bottle']
            self.phone_conf_threshold = 0.15  # Very sensitive for phones
            self.contraband_conf_threshold = 0.25  # Lowered from 0.5 for knives/scissors
            print(f"YOLOv8 loaded! Phone threshold: {self.phone_conf_threshold}, Others: {self.contraband_conf_threshold}")
        except ImportError:
            print("WARNING: ultralytics not installed. YOLO disabled.")
            print("Install with: pip install ultralytics")
            self.enable_yolo = False
            self.yolo_device = 'cpu'

    def detect_motion(self, frame, camera_id):
        """
        STAGE 1: Motion Detection (Lightweight)
        Returns True if significant motion detected.
        """
        # Initialize for new camera
        if camera_id not in self.bg_subtractors:
            self.bg_subtractors[camera_id] = cv2.createBackgroundSubtractorMOG2(
                history=500,
                varThreshold=16,
                detectShadows=False
            )
            self.motion_history[camera_id] = deque(maxlen=self.motion_history_size)
            self.last_gray_frames[camera_id] = None

        # Convert to grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (21, 21), 0)

        # METHOD 1: Background Subtraction
        fg_mask = self.bg_subtractors[camera_id].apply(gray)
        motion_pixels_bg = cv2.countNonZero(fg_mask)

        # METHOD 2: Frame Differencing (if we have previous frame)
        motion_pixels_diff = 0
        if self.last_gray_frames[camera_id] is not None:
            frame_diff = cv2.absdiff(self.last_gray_frames[camera_id], gray)
            _, thresh = cv2.threshold(frame_diff, 25, 255, cv2.THRESH_BINARY)
            motion_pixels_diff = cv2.countNonZero(thresh)

        # Update last frame
        self.last_gray_frames[camera_id] = gray

        # Combine both methods
        motion_score = max(motion_pixels_bg, motion_pixels_diff)

        # Add to history for smoothing
        self.motion_history[camera_id].append(motion_score)
        avg_motion = np.mean(self.motion_history[camera_id])

        # Determine if motion is significant
        motion_detected = avg_motion > self.motion_threshold

        if self.debug and motion_detected:
            print(f"[{camera_id}] Motion: {avg_motion:.0f} pixels (threshold: {self.motion_threshold})")

        return motion_detected, avg_motion

    def process_frame(self, frame, camera_id="cam_0"):
        """
        Main processing pipeline with motion optimization.

        Returns dict with:
        - frame: processed frame
        - motion_detected: bool
        - motion_score: float
        - num_people: int
        - alert_triggered: bool
        - alerts: list
        - detections: dict
        - processing_mode: "motion_only" or "full_ai"
        """
        with self.lock:
            self.stats['total_frames'] += 1

        # STAGE 1: Quick motion check
        motion_detected, motion_score = self.detect_motion(frame, camera_id)

        results = {
            "frame": frame.copy(),
            "motion_detected": motion_detected,
            "motion_score": motion_score,
            "num_people": 0,
            "alert_triggered": False,
            "active_movement": False,
            "alerts": [],
            "detections": {"behavior": [], "contraband": []},
            "processing_mode": "motion_only"
        }

        # If NO motion detected, skip heavy AI processing
        if not motion_detected:
            with self.lock:
                self.stats['skipped_frames'] += 1

            # Draw "NO MOTION" indicator
            cv2.putText(results["frame"], "No Motion - AI Idle",
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                        0.7, (128, 128, 128), 2)

            return results

        # THROTTLING: Only run heavy AI every 60ms (~16 FPS) per camera
        current_time = time.time()
        last_time = self.last_process_time.get(camera_id, 0)
        if current_time - last_time < 0.06:  # 60ms threshold
            results["processing_mode"] = "motion_only (throttled)"
            cv2.putText(results["frame"], "AI Throttled (15 FPS)",
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                        0.7, (0, 255, 255), 2)
            return results

        self.last_process_time[camera_id] = current_time

        # STAGE 2: Motion detected - Run full AI processing
        with self.lock:
            self.stats['motion_detected'] += 1
            self.stats['ai_processed'] += 1
        results["processing_mode"] = "full_ai"

        # --- ENGINE 1: MoveNet Pose Detection ---
        if self.movenet:
            try:
                input_image = cv2.resize(frame, (256, 256))
                input_image = tf.cast(input_image, dtype=tf.int32)
                input_image = tf.expand_dims(input_image, axis=0)

                if self.gpu_enabled:
                    with tf.device('/GPU:0'):
                        output = self.movenet(input_image)
                else:
                    output = self.movenet(input_image)
                keypoints_with_scores = output["output_0"].numpy()

                # Process each detected person
                for person_id in range(6):
                    kps = keypoints_with_scores[0, person_id, :51].reshape(17, 3)
                    avg_confidence = np.mean(kps[:, 2])

                    if avg_confidence > 0.25:
                        results["num_people"] += 1

                        # Draw pose
                        self.draw_pose(results["frame"], kps, person_id)

                        # Classify behavior
                        label, score = self.classify_behavior(kps, person_id, camera_id)
                        self.draw_label(results["frame"], kps, person_id, label, score)

                        detection = {
                            "person_id": person_id,
                            "label": label,
                            "score": score,
                            "confidence": avg_confidence
                        }
                        results["detections"]["behavior"].append(detection)

                        if "Aggressive" in label:
                            results["alert_triggered"] = True
                            results["alerts"].append(f"Person {person_id + 1}: {label}")
                        elif "Fast" in label or "Active" in label:
                            results["active_movement"] = True
            except Exception as e:
                if self.debug:
                    print(f"MoveNet Runtime Error: {e}")

        # --- ENGINE 2: YOLO Support (Contraband + Fallback Pose) ---
        if self.enable_yolo:
            # If MoveNet is missing, use YOLO-Pose for skeletons
            if not self.movenet:
                try:
                    if self.yolo_pose_model is None:
                        from ultralytics import YOLO
                        print(f"Loading YOLOv8-Pose... (Device: {self.yolo_device})")
                        self.yolo_pose_model = YOLO('yolov8n-pose.pt')
                    
                    pose_results = self.yolo_pose_model(frame, verbose=False, 
                                                       device=self.yolo_device,
                                                       imgsz=self.yolo_imgsz)
                    
                    for pose_res in pose_results:
                        if pose_res.keypoints is not None:
                            results["num_people"] = len(pose_res.keypoints)
                            for i, kpts in enumerate(pose_res.keypoints.data):
                                results_kps = kpts.cpu().numpy()
                                self.draw_pose(results["frame"], results_kps, i)
                                cv2.putText(results["frame"], f"Person {i+1} (YOLO-Pose)",
                                           (int(results_kps[0][0]), int(results_kps[0][1]) - 10),
                                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
                except Exception as e:
                    if self.debug:
                        print(f"YOLO-Pose Fallback Error: {e}")

            # Always run YOLO Contraband detection
            contraband = self.detect_contraband(results["frame"])
            results["detections"]["contraband"] = contraband

            if contraband:
                results["alert_triggered"] = True
                for item in contraband:
                    results["alerts"].append(f"Contraband: {item['item']}")
            
            # If neither MoveNet nor YOLO-Pose detected people, run standard YOLO person detection
            if results["num_people"] == 0:
                people_detected = self.detect_people_yolo(results["frame"])
                results["num_people"] = len(people_detected)
                for person in people_detected:
                    x1, y1, x2, y2 = person['bbox']
                    cv2.rectangle(results["frame"], (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.putText(results["frame"], f"Person {person['confidence']:.2f}",
                                (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

            results["detections"]["contraband"] = contraband

            if contraband:
                results["alert_triggered"] = True
                for item in contraband:
                    results["alerts"].append(f"Contraband: {item['item']}")

        # Draw motion indicator
        cv2.putText(results["frame"], "AI ACTIVE - Motion Detected",
                    (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                    0.7, (0, 255, 0), 2)

        return results

    def detect_contraband(self, frame):
        """YOLO contraband detection."""
        if not self.enable_yolo:
            return []

        detections = []
        # Run YOLO with auto-detected device and reduced imgsz
        results = self.yolo_model(frame, verbose=False, 
                                  device=self.yolo_device, 
                                  imgsz=self.yolo_imgsz)

        for result in results:
            for box in result.boxes:
                class_id = int(box.cls)
                class_name = self.yolo_model.names[class_id]
                confidence = float(box.conf)

                # Use lower threshold for phones
                threshold = self.phone_conf_threshold if class_name == 'cell phone' else self.contraband_conf_threshold

                if class_name in self.contraband_items and confidence > threshold:
                    x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()

                    if self.debug:
                        print(f"CONTRABAND DETECTED: {class_name} ({confidence:.2f})")

                    detections.append({
                        'item': class_name,
                        'confidence': confidence,
                        'bbox': (int(x1), int(y1), int(x2), int(y2))
                    })

                    # Draw box
                    cv2.rectangle(frame,
                                  (int(x1), int(y1)),
                                  (int(x2), int(y2)),
                                  (0, 0, 255), 3)

                    label = f"{class_name} {confidence:.2f}"
                    cv2.putText(frame, label,
                                (int(x1), int(y1) - 10),
                                cv2.FONT_HERSHEY_SIMPLEX,
                                0.7, (0, 0, 255), 2)

        return detections

    def detect_people_yolo(self, frame):
        """Detect people using YOLO (fallback when MoveNet unavailable)."""
        if not self.enable_yolo:
            return []

        people = []
        # Run YOLO with auto-detected device and reduced imgsz
        results = self.yolo_model(frame, verbose=False, 
                                  device=self.yolo_device,
                                  imgsz=self.yolo_imgsz)

        for result in results:
            for box in result.boxes:
                class_id = int(box.cls)
                class_name = self.yolo_model.names[class_id]
                confidence = float(box.conf)

                if class_name == 'person' and confidence > 0.5:
                    x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                    people.append({
                        'confidence': confidence,
                        'bbox': (int(x1), int(y1), int(x2), int(y2))
                    })

        return people

    def draw_pose(self, frame, keypoints, person_id, threshold=0.3):
        """Draw skeletal overlay."""
        h, w, _ = frame.shape
        colors = [(0, 255, 0), (255, 0, 0), (0, 255, 255),
                  (255, 255, 0), (255, 0, 255), (128, 255, 0)]
        color = colors[person_id % len(colors)]

        for y, x, c in keypoints:
            if c > threshold:
                cv2.circle(frame, (int(x * w), int(y * h)), 6, color, -1)
                cv2.circle(frame, (int(x * w), int(y * h)), 8, (255, 255, 255), 1)

        for p1, p2 in self.EDGES:
            y1, x1, c1 = keypoints[p1]
            y2, x2, c2 = keypoints[p2]
            if c1 > threshold and c2 > threshold:
                cv2.line(frame,
                         (int(x1 * w), int(y1 * h)),
                         (int(x2 * w), int(y2 * h)),
                         color, 3)

    def classify_behavior(self, keypoints, person_id, camera_id):
        """Rule-based behavior classification."""
        if camera_id not in self.trackers:
            self.trackers[camera_id] = {}

        tracker_map = self.trackers[camera_id]

        k = keypoints
        left_wrist = k[9][:2]
        right_wrist = k[10][:2]
        left_elbow = k[7][:2]
        right_elbow = k[8][:2]

        now = time.time()

        if person_id not in tracker_map:
            tracker_map[person_id] = {
                'prev_right_wrist': right_wrist,
                'prev_left_wrist': left_wrist,
                'prev_right_elbow': right_elbow,
                'prev_left_elbow': left_elbow,
                'prev_time': now,
                'motion_history': [],
                'alert_count': 0
            }
            return "Normal", 0.0

        tracker = tracker_map[person_id]
        dt = now - tracker['prev_time']

        if dt == 0 or dt > 0.5:
            tracker['prev_time'] = now
            return "Normal", 0.0

        # Calculate speeds
        right_wrist_speed = np.linalg.norm(right_wrist - tracker['prev_right_wrist']) / dt
        left_wrist_speed = np.linalg.norm(left_wrist - tracker['prev_left_wrist']) / dt
        right_elbow_speed = np.linalg.norm(right_elbow - tracker['prev_right_elbow']) / dt
        left_elbow_speed = np.linalg.norm(left_elbow - tracker['prev_left_elbow']) / dt

        wrist_motion = (right_wrist_speed + left_wrist_speed) / 2
        elbow_motion = (right_elbow_speed + left_elbow_speed) / 2
        motion_score = (wrist_motion * 0.7) + (elbow_motion * 0.3)

        # Update tracker
        tracker['prev_right_wrist'] = right_wrist
        tracker['prev_left_wrist'] = left_wrist
        tracker['prev_right_elbow'] = right_elbow
        tracker['prev_left_elbow'] = left_elbow
        tracker['prev_time'] = now

        tracker['motion_history'].append(motion_score)
        if len(tracker['motion_history']) > 5:
            tracker['motion_history'].pop(0)

        avg_motion = np.mean(tracker['motion_history'])

        if self.debug:
            print(f"[{camera_id}] P{person_id}: Behavior Motion={avg_motion:.3f}")

        # Classification
        if avg_motion > self.AGGRESSIVE_THRESHOLD:
            tracker['alert_count'] += 1
            if tracker['alert_count'] >= self.ALERT_FRAMES:
                return "Suspicious / Aggressive", avg_motion
            else:
                return "Fast Movement", avg_motion
        else:
            tracker['alert_count'] = max(0, tracker['alert_count'] - 1)

            if avg_motion > self.ACTIVE_THRESHOLD:
                return "Active Movement", avg_motion
            else:
                return "Normal", avg_motion

    def draw_label(self, frame, kps, person_id, label, score):
        """Draw behavior label near person."""
        h, w, _ = frame.shape
        nose = kps[0]

        label_x = max(10, min(int(nose[1] * w), w - 300))
        label_y = max(40, int(nose[0] * h) - 30)

        if "Aggressive" in label:
            color = (0, 0, 255)
        elif "Fast" in label or "Active" in label:
            color = (0, 165, 255)
        else:
            color = (0, 255, 0)

        text = f"P{person_id + 1}: {label}"
        text_size = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.65, 2)[0]

        overlay = frame.copy()
        cv2.rectangle(overlay,
                      (label_x - 6, label_y - text_size[1] - 6),
                      (label_x + text_size[0] + 6, label_y + 6),
                      (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.6, frame, 0.4, 0, frame)

        cv2.putText(frame, text, (label_x, label_y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.65, color, 2)
        cv2.putText(frame, f"Motion: {score:.2f}",
                    (label_x, label_y + 22),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

    def get_stats(self):
        """Get performance statistics."""
        total = self.stats['total_frames']
        if total == 0:
            return "No frames processed yet"

        efficiency = (self.stats['skipped_frames'] / total) * 100

        return {
            'total_frames': total,
            'motion_detected': self.stats['motion_detected'],
            'ai_processed': self.stats['ai_processed'],
            'skipped_frames': self.stats['skipped_frames'],
            'efficiency': f"{efficiency:.1f}%"
        }

    def reset_tracker(self, camera_id=None):
        """Reset tracking data."""
        if camera_id is None:
            self.trackers = {}
            self.bg_subtractors = {}
            self.motion_history = {}
            self.last_gray_frames = {}
            print("All trackers reset")
        else:
            if camera_id in self.trackers:
                self.trackers[camera_id] = {}
            if camera_id in self.bg_subtractors:
                del self.bg_subtractors[camera_id]
            if camera_id in self.motion_history:
                del self.motion_history[camera_id]
            if camera_id in self.last_gray_frames:
                del self.last_gray_frames[camera_id]
            print(f"Tracker reset for camera: {camera_id}")


class MoveNetEngine:
    def __init__(self, debug=False, sensitivity="medium"):

        """
        Initialize MoveNet engine.
        
        Args:
            debug: If True, prints motion scores for tuning
            sensitivity: "high", "medium", or "low" detection sensitivity
        """
        print("Initializing MoveNetEngine...")
        self.debug = debug
        self.set_sensitivity(sensitivity)
        self.check_gpu()
        self.model = self.load_model()
        self.movenet = self.model.signatures["serving_default"]
        
        self.EDGES = [
            (0, 1), (0, 2), (1, 3), (2, 4),
            (0, 5), (0, 6), (5, 7), (7, 9),
            (6, 8), (8, 10), (5, 6), (5, 11),
            (6, 12), (11, 12), (11, 13), (13, 15),
            (12, 14), (14, 16)
        ]
        
        self.trackers = {}

    def set_sensitivity(self, level):
        """Set detection sensitivity thresholds."""
        if level == "high":
            self.AGGRESSIVE_THRESHOLD = 0.3
            self.ACTIVE_THRESHOLD = 0.15
            self.ALERT_FRAMES = 2
            print("Sensitivity: HIGH (for testing/demos)")
        elif level == "low":
            self.AGGRESSIVE_THRESHOLD = 1.5
            self.ACTIVE_THRESHOLD = 0.8
            self.ALERT_FRAMES = 5
            print("Sensitivity: LOW (for production)")
        else:  # medium
            self.AGGRESSIVE_THRESHOLD = 0.5
            self.ACTIVE_THRESHOLD = 0.25
            self.ALERT_FRAMES = 3
            print("Sensitivity: MEDIUM (balanced)")

    def check_gpu(self):
        if not TF_AVAILABLE:
            print(f"TensorFlow not available, skipping GPU check. ({TF_IMPORT_ERROR})")
            return False

        print("Checking GPU availability...")
        gpus = tf.config.list_physical_devices('GPU')
        if gpus:
            try:
                for gpu in gpus:
                    tf.config.experimental.set_memory_growth(gpu, True)
                print(f"GPU ENABLED: {gpus[0].name}")
                return True
            except RuntimeError as e:
                print(f"GPU Error: {e}")
                return False
        else:
            print("WARNING: Running on CPU")
            return False

    def load_model(self):
        if not TF_AVAILABLE:
            raise RuntimeError(f"TensorFlow not available - cannot load MoveNet model ({TF_IMPORT_ERROR})")
        if not HUB_AVAILABLE:
            raise RuntimeError(f"tensorflow_hub not available - cannot load MoveNet model ({HUB_IMPORT_ERROR})")
        
        print("Loading MoveNet MultiPose model...")
        try:
            model = hub.load("https://tfhub.dev/google/movenet/multipose/lightning/1")
            print("Model loaded successfully!")
            return model
        except Exception as e:
            raise RuntimeError(f"Failed to load MoveNet model: {e}")

    def process_frame(self, frame, camera_id="cam_0"):
        """Process a single frame and return detection results."""
        # Resize for model input
        input_image = cv2.resize(frame, (256, 256))
        input_image = tf.cast(input_image, dtype=tf.int32)
        input_image = tf.expand_dims(input_image, axis=0)

        # Run inference
        output = self.movenet(input_image)
        keypoints_with_scores = output["output_0"].numpy()

        # Initialize results
        results = {
            "frame": frame.copy(),
            "num_people": 0,
            "alert_triggered": False,
            "active_movement": False,
            "alerts": [],
            "detections": []
        }
        
        for person_id in range(6):
            kps = keypoints_with_scores[0, person_id, :51].reshape(17, 3)
            avg_confidence = np.mean(kps[:, 2])

            if avg_confidence > 0.25:
                results["num_people"] += 1
                
                self.draw_pose(results["frame"], kps, person_id)
                label, score = self.classify_behavior(kps, person_id, camera_id)
                self.draw_label(results["frame"], kps, person_id, label, score)
                
                detection = {
                    "person_id": person_id,
                    "label": label,
                    "score": score,
                    "confidence": avg_confidence
                }
                results["detections"].append(detection)
                
                if "Aggressive" in label:
                    results["alert_triggered"] = True
                    results["alerts"].append(f"Person {person_id + 1}: {label}")
                elif "Fast" in label or "Active" in label:
                    results["active_movement"] = True

        return results

    def draw_pose(self, frame, keypoints, person_id, threshold=0.3):
        """Draw skeletal overlay on frame."""
        h, w, _ = frame.shape
        colors = [(0, 255, 0), (255, 0, 0), (0, 255, 255),
                  (255, 255, 0), (255, 0, 255), (128, 255, 0)]
        color = colors[person_id % len(colors)]

        for y, x, c in keypoints:
            if c > threshold:
                cv2.circle(frame, (int(x * w), int(y * h)), 6, color, -1)
                cv2.circle(frame, (int(x * w), int(y * h)), 8, (255, 255, 255), 1)

        for p1, p2 in self.EDGES:
            y1, x1, c1 = keypoints[p1]
            y2, x2, c2 = keypoints[p2]
            if c1 > threshold and c2 > threshold:
                cv2.line(frame,
                         (int(x1 * w), int(y1 * h)),
                         (int(x2 * w), int(y2 * h)),
                         color, 3)

    def classify_behavior(self, keypoints, person_id, camera_id):
        """Classify behavior based on keypoint motion analysis."""
        if camera_id not in self.trackers:
            self.trackers[camera_id] = {}
            
        tracker_map = self.trackers[camera_id]
        
        k = keypoints
        left_wrist = k[9][:2]
        right_wrist = k[10][:2]
        left_elbow = k[7][:2]
        right_elbow = k[8][:2]

        now = time.time()

        if person_id not in tracker_map:
            tracker_map[person_id] = {
                'prev_right_wrist': right_wrist,
                'prev_left_wrist': left_wrist,
                'prev_right_elbow': right_elbow,
                'prev_left_elbow': left_elbow,
                'prev_time': now,
                'motion_history': [],
                'alert_count': 0
            }
            return "Normal", 0.0

        tracker = tracker_map[person_id]
        dt = now - tracker['prev_time']

        if dt == 0 or dt > 0.5:
            tracker['prev_time'] = now
            return "Normal", 0.0

        # Calculate speeds
        right_wrist_speed = np.linalg.norm(right_wrist - tracker['prev_right_wrist']) / dt
        left_wrist_speed = np.linalg.norm(left_wrist - tracker['prev_left_wrist']) / dt
        right_elbow_speed = np.linalg.norm(right_elbow - tracker['prev_right_elbow']) / dt
        left_elbow_speed = np.linalg.norm(left_elbow - tracker['prev_left_elbow']) / dt

        wrist_motion = (right_wrist_speed + left_wrist_speed) / 2
        elbow_motion = (right_elbow_speed + left_elbow_speed) / 2
        motion_score = (wrist_motion * 0.7) + (elbow_motion * 0.3)

        # Update tracker
        tracker['prev_right_wrist'] = right_wrist
        tracker['prev_left_wrist'] = left_wrist
        tracker['prev_right_elbow'] = right_elbow
        tracker['prev_left_elbow'] = left_elbow
        tracker['prev_time'] = now

        tracker['motion_history'].append(motion_score)
        if len(tracker['motion_history']) > 5:
            tracker['motion_history'].pop(0)

        avg_motion = np.mean(tracker['motion_history'])
        
        # DEBUG MODE
        if self.debug:
            print(f"Cam {camera_id}, P{person_id}: Motion={avg_motion:.3f}")

        # Use configurable thresholds
        if avg_motion > self.AGGRESSIVE_THRESHOLD:
            tracker['alert_count'] += 1
            if tracker['alert_count'] >= self.ALERT_FRAMES:
                return "Suspicious / Aggressive", avg_motion
            else:
                return "Fast Movement", avg_motion
        else:
            tracker['alert_count'] = max(0, tracker['alert_count'] - 1)
            
            if avg_motion > self.ACTIVE_THRESHOLD:
                return "Active Movement", avg_motion
            else:
                return "Normal", avg_motion

    def draw_label(self, frame, kps, person_id, label, score):
        """Draw behavior label near detected person."""
        h, w, _ = frame.shape
        nose = kps[0]
        
        label_x = max(10, min(int(nose[1] * w), w - 300))
        label_y = max(40, int(nose[0] * h) - 30)

        if "Aggressive" in label:
            color = (0, 0, 255)
        elif "Fast" in label or "Active" in label:
            color = (0, 165, 255)
        else:
            color = (0, 255, 0)

        text = f"P{person_id + 1}: {label}"
        text_size = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.65, 2)[0]
        
        overlay = frame.copy()
        cv2.rectangle(overlay,
                      (label_x - 6, label_y - text_size[1] - 6),
                      (label_x + text_size[0] + 6, label_y + 6),
                      (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.6, frame, 0.4, 0, frame)

        cv2.putText(frame, text, (label_x, label_y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.65, color, 2)
        cv2.putText(frame, f"Motion: {score:.2f}",
                    (label_x, label_y + 22),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

    def reset_tracker(self, camera_id=None, person_id=None):
        """Reset tracking data."""
        if camera_id is None:
            self.trackers = {}
            print("All trackers reset")
        elif person_id is None:
            if camera_id in self.trackers:
                self.trackers[camera_id] = {}
                print(f"Tracker reset for camera: {camera_id}")
        else:
            if camera_id in self.trackers and person_id in self.trackers[camera_id]:
                del self.trackers[camera_id][person_id]
                print(f"Tracker reset for camera {camera_id}, person {person_id}")


# TEST WITH DUAL ENGINES
if __name__ == "__main__":
    # MoveNet (working)
    if not TF_AVAILABLE:
        print("TensorFlow not available. Exiting.")
        raise SystemExit(1)

    movenet = MoveNetEngine(debug=True, sensitivity="high")

    # YOLO phone-only
    try:
        yolo_phone = YOLOPhoneOnlyEngine(
            model_path="yolov8n.pt",
            debug=False,
            conf=0.10,     # make it sensitive
            iou=0.45,
            device="cpu"   # change to "0" if you have GPU
        )
    except Exception as e:
        print(f"YOLO phone init failed: {e}")
        yolo_phone = None

    cap = cv2.VideoCapture(0)

    print("\n" + "="*50)
    print("Press 'q' to quit")
    print("Tips: turn on lights, bring phone closer, show screen side")
    print("="*50 + "\n")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # 1) Pose overlay + rule-based motion label
        out_pose = movenet.process_frame(frame, camera_id="webcam_0")

        # 2) Run YOLO on SAME frame (draw phone boxes on top)
        if yolo_phone is not None:
            out_yolo = yolo_phone.process_frame(out_pose["frame"], camera_id="webcam_0")
            out_pose["frame"] = out_yolo["frame"]
            # You can print alert if phone is detected
            if out_yolo["alert_triggered"]:
                print("YOLO ALERT:", out_yolo["alerts"])

        cv2.imshow("MoveNet + YOLO Phone", out_pose["frame"])

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
